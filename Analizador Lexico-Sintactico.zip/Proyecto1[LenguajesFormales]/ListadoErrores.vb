﻿Public Class ListadoErrores


    Sub New()

        inicio = Nothing

        fin = Nothing

    End Sub

    Sub AgregarError(ByVal ser As Integer, ByVal lexE As String, ByVal tipo As String,
                     ByVal colE As Integer, ByVal filE As Integer, ByVal descrip As String)

        inicio = New NodoErrores(ser, lexE, tipo, colE, filE, descrip, inicio)

        If IsDBNull(fin) Then

            fin = inicio

        End If

        contError += 1

    End Sub

    Function mostrarErrores() As String
        Dim recorrer As NodoErrores = inicio

        Dim concatena As String = ""

        For k = 0 To contError - 1

            concatena = concatena & "<tr>" & "<td>" & Convert.ToString(recorrer.serial) & "</td>" &
                "         " & "<td>" & recorrer.lexError & "</td>" & "        " & "<td>" & recorrer.tipoError & "</td>" & "        " & "<td>" & Convert.ToString(recorrer.columError) & "</td>" &
                "         " & "<td>" & Convert.ToString(recorrer.FilError) & "</td>" & "        " & "<td>" & recorrer.descripcion & "</td>" & "</tr>" & Environment.NewLine

            recorrer = recorrer.siguiente

        Next

        Return concatena

    End Function


    Public inicio, fin As NodoErrores

    Public contError As Integer = 0
End Class
