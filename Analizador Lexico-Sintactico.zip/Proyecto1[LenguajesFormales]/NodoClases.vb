﻿Public Class NodoClases

    Sub New(ByVal nomClass As String)

        Me.nombreClase = nomClass

    End Sub

    Sub New(ByVal nomClass As String, ByVal nodSig As NodoClases)

        Me.nombreClase = nomClass

        Me.siguiente = nodSig

    End Sub


    Public nombreClase As String

    Public siguiente As NodoClases
End Class
