﻿Public Class ListaClases

    Sub New()

        inicio = Nothing

        fin = Nothing

    End Sub

    Sub AgregarClase(ByVal nomClass As String) 'agregamos el nombre de una clase a la lista

        inicio = New NodoClases(nomClass, inicio)

        If IsDBNull(fin) Then

            fin = inicio

        End If

        contador += 1

    End Sub

	Function ExisteClase(ByVal nomClase As String) As Boolean 'verifica que existe la clase y nos devuelve un booleano

		Dim recorrer As NodoClases = inicio 'usar doble if anidado para verificar que las dos clases existan y asi poder crear el grafico

		Dim existe As Boolean = False

        'While Not IsDBNull(recorrer)
        For p = 0 To contador - 1


            If String.Compare(recorrer.nombreClase, nomClase, True) = 0 Then
                'recorrer.nombreClase = nomClase
                existe = True

                Exit For

                'Exit While

            End If

            recorrer = recorrer.siguiente

        Next
        'End While

        Return existe

	End Function

    Sub mostrarClases()
        Dim recorrer As NodoClases = inicio

        Dim aux As String = ""

        For k = 0 To contador - 1

            aux = aux & recorrer.nombreClase & Environment.NewLine

            recorrer = recorrer.siguiente

        Next

        'While Not IsDBNull(recorrer)



        'End While

        MessageBox.Show(aux)

    End Sub

    Function validaClases(ByVal nomClase As String) As Boolean
        Dim recorrer2 As NodoClases = inicio

        Dim existe As Boolean = False

        For K = 0 To contador - 1

            If String.Compare(nomClase, recorrer2.nombreClase, True) = 0 Then
                'nomClase = recorrer2.nombreClase
                existe = True

                Exit For

            End If

            recorrer2 = recorrer2.siguiente

        Next

        Return existe

    End Function


    Public NombreClase As String

	Public inicio, fin As NodoClases

	Public contador As Integer = 0

End Class
