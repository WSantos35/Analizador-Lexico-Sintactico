﻿Public Class PPrincipal
    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MSalir.Click
        Close()
    End Sub

    Private Sub MAbrir_Click(sender As Object, e As EventArgs) Handles MAbrir.Click

        Dim abrir As New OpenFileDialog

        abrir.Filter = "Archivo .lfp | *.lfp" 'filtro para abrir archivos solo con extensión .lfp

        If abrir.ShowDialog() = DialogResult.OK Then

            ruta = abrir.FileName

            Me.richATexto.LoadFile(ruta, RichTextBoxStreamType.PlainText) 'Escribe en el richtextbox lo que obtenga de cualquier archivo .lfp

            If System.IO.File.Exists(ruta) Then

                existe = True

            End If

        End If

    End Sub

    Private Sub MGuardarComo_Click(sender As Object, e As EventArgs) Handles MGuardarComo.Click

        Dim Guardar2 As New SaveFileDialog

        Guardar2.Filter = "Archivo .lfp | *.lfp"

        If Guardar2.ShowDialog() = DialogResult.OK Then

            ruta = Guardar2.FileName

            CreaArchivo(ruta)

            If System.IO.File.Exists(ruta) Then

                existe = True

            End If

            MessageBox.Show("Archivo Guardado Exitosamente!")

        End If


    End Sub

    Private Sub MGuardar_Click(sender As Object, e As EventArgs) Handles MGuardar.Click

        Dim Guardar As New SaveFileDialog

        If Not existe Then

            Guardar.Filter = "Archivo .lfp | *.lfp"

            If Guardar.ShowDialog() = DialogResult.OK Then

                ruta = Guardar.FileName

                CreaArchivo(ruta)

                existe = True

                MessageBox.Show("Archivo Guardado Exitosamente!")

            End If

        Else

            CreaArchivo(ruta)

            MessageBox.Show("Cambios Guardados Exitosamente!")


        End If

    End Sub

    Sub CreaArchivo(ByVal path As String) 'crea y modifica los archivos

        Dim archivo As New IO.StreamWriter(path)

        archivo.Write(richATexto.Text)

        archivo.Flush() 'fuerza a reescribir el archivo

        archivo.Close()

    End Sub

    Private Sub MAnLexico_Click(sender As Object, e As EventArgs) Handles MAnLexico.Click

        contenidoArchivo = New String(richATexto.Text)

        AnalizadorLexico(contenidoArchivo) 'Realiza el analisis lexico

        Preanalisis = Split(misTokens.ListaToken, vbNewLine)

        sigToken = Preanalisis.Length - 2

        Ko() 'Realiza el analisis sintactico mediante el metodo recursivo


    End Sub

    '-------------------------------------------Metodos analisis sintacticos----------------------------------------------

    Sub Ko()

        Try
            If Preanalisis(sigToken) = "[" Then
                Console.WriteLine(Preanalisis(sigToken))
                sigToken -= 1
                K1()
                If Preanalisis(sigToken) = "]" Then
                    Console.WriteLine(Preanalisis(sigToken))
                    sigToken -= 1
                    K2()
                Else
                    EstadoError()
                End If
            Else
                EstadoError()
            End If
        Catch ex As Exception
            MessageBox.Show("Analisis sintactico terminado")
        End Try

    End Sub

    Sub K1()

        If String.Compare(Preanalisis(sigToken), "Clase", True) = 0 Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
        ElseIf String.Compare(Preanalisis(sigToken), "Asociacion", True) = 0 Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
        ElseIf String.Compare(Preanalisis(sigToken), "Comentario", True) = 0 Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
        ElseIf String.Compare(Preanalisis(sigToken), "Nombre", True) = 0 Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
        ElseIf String.Compare(Preanalisis(sigToken), "Texto", True) = 0 Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
        ElseIf String.Compare(Preanalisis(sigToken), "Atributos", True) = 0 Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
        ElseIf String.Compare(Preanalisis(sigToken), "Metodos", True) = 0 Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
        ElseIf String.Compare(Preanalisis(sigToken), "Color", True) = 0 Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
        Else
            EstadoError()
        End If

    End Sub

    Sub K2()

        If Preanalisis(sigToken) = "{" Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
            K3()
            If Preanalisis(sigToken) = "}" Then
                Console.WriteLine(Preanalisis(sigToken))
                sigToken -= 1
                K10()
            Else
                EstadoError()
            End If

        ElseIf Preanalisis(sigToken) = "=" Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
            K8()
            If Preanalisis(sigToken) = ";" Then
                Console.WriteLine(Preanalisis(sigToken))
                sigToken -= 1
                K3()
            End If
        Else
            EstadoError()
        End If

    End Sub

    Sub K3()
        If Preanalisis(sigToken) = "[" Then
            Ko()
        ElseIf Preanalisis(sigToken) = "(" Then
            K4()
        ElseIf Preanalisis(sigToken) = "}" Then

        ElseIf Char.IsLetter(Preanalisis(sigToken)) = True Then
            K6()
        Else
            EstadoError()
        End If
    End Sub


    Sub K4()
        If Preanalisis(sigToken) = "(" Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
            K5()
            If Preanalisis(sigToken) = ")" Then
                Console.WriteLine(Preanalisis(sigToken))
                sigToken -= 1
                K6()
            Else
                EstadoError()
            End If
        Else
            EstadoError()
        End If
    End Sub

    Sub K5()
        If Preanalisis(sigToken) = "+" Or Preanalisis(sigToken) = "-" Or Preanalisis(sigToken) = "#" Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
        Else
            EstadoError()
        End If
    End Sub

    Sub K6()
        If Char.IsLetter(Preanalisis(sigToken)) = True Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
            K7()
        Else
            EstadoError()
        End If
    End Sub

    Sub K7()
        If Preanalisis(sigToken) = ":" Then
            Console.WriteLine(Preanalisis(sigToken))

            sigToken -= 1

            K6()
        ElseIf Preanalisis(sigToken) = ";" Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
            K3()
        Else
            EstadoError()
        End If
    End Sub

    Sub K8()
        If Char.IsLetter(Preanalisis(sigToken)) = True Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
        ElseIf Char.IsDigit(Preanalisis(sigToken)) = True Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
            K9()
        ElseIf Preanalisis(sigToken) = Chr(34) Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
            K8()
            If Preanalisis(sigToken) = Chr(34) Then
                Console.WriteLine(Preanalisis(sigToken))
                sigToken -= 1
                K9()
            Else
                EstadoError()
            End If
        Else
            EstadoError()
        End If
    End Sub

    Sub K9()
        If Preanalisis(sigToken) = "," Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
            K8()

        ElseIf Preanalisis(sigToken) = ";" Then
            Console.WriteLine(Preanalisis(sigToken))
            sigToken -= 1
            K3()
        Else
            EstadoError()
        End If
    End Sub

    Sub K10()
        If Preanalisis(sigToken) = "[" Then
            Console.WriteLine(Preanalisis(sigToken))
            Ko()
        ElseIf Preanalisis(sigToken) = "}" Then
        Else
            EstadoError()
        End If
    End Sub

    Sub EstadoError()
        MessageBox.Show("Se encontro error sintactico, Verificar su lenguaje!!")
    End Sub

    '------------------------------------------------------------------------------------------------------------------


    Sub AnalizadorLexico(ByVal Contenido As String)


        Dim filas() As String = Split(Contenido, vbNewLine)

        For i = 0 To (filas.Length - 1) 'toma cada fila para ir analizando

            caracteres = filas(i) 'obtiene la cadena total de la 

            For j = 0 To (caracteres.Length - 1) 'toma la cantiidad de caracteres de la de la fila

                Select Case estado

                    Case 0

                        If isSimbolo(caracteres(j)) = True Then 'Verifica que sea un simbolo reconocido por el lenguaje


                            estado = 1

                            auxiliar = auxiliar + (caracteres(j))

                            pintaSimbolos(caracteres(j))

                            contColumnas += 1

                        ElseIf caracteres(j) = " " Then

                            contColumnas += 1

                        ElseIf caracteres(j) = Chr(9) Or caracteres(j) = Chr(13) Or caracteres(j) = Chr(8) Then

                        ElseIf caracteres(j) = Chr(10) Then

                            contFilas += 1

                            contColumnas = 0

                        Else

                            Reportes = False

                                contColumnas += 1

                                contadorError += 1

                            misErrores.AgregarError(contadorError, caracteres(j), "Error Lexico", contColumnas, contFilas, "Simbolo no reconocido")

                            setColores(caracteres(j), Color.Blue)

                        End If
                        
                            Case 1

                        If isSimbolo(caracteres(j)) = True Then

                            estado = 2

                            auxiliar = auxiliar + caracteres(j)

                            Analisis()

                            pintaSimbolos(caracteres(j))

                            contColumnas += 1

                        ElseIf Char.IsLetter(caracteres(j)) Or caracteres(j) = "_" Then


                            estado = 2

                            auxiliar = auxiliar + caracteres(j)

                            auxiliar2 = auxiliar2 + caracteres(j)

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                            contColumnas += 1

                        ElseIf Char.IsDigit(caracteres(j)) Or caracteres(j) = "_" Then

                            estado = 2

                            auxiliar = auxiliar + caracteres(j)

                            auxiliar2 = auxiliar2 + caracteres(j)

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                            contColumnas += 1

                        ElseIf caracteres(j) = " " Then

                            contColumnas += 1
                            auxiliarPintar = auxiliarPintar + caracteres(j)

                        ElseIf caracteres(j) = Chr(34) Then

                        ElseIf caracteres(j) = Chr(9) Or caracteres(j) = Chr(13) Or caracteres(j) = Chr(8) Then

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                        ElseIf caracteres(j) = Chr(10) Then

                            contFilas += 1

                            contColumnas = 0

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                        Else

                            Reportes = False

                                contColumnas += 1

                            contadorError += 1

                            setColores(caracteres(j), Color.Blue)

                            misErrores.AgregarError(contadorError, caracteres(j), "Error lexico", contColumnas, contFilas, "Simbolo no reconocido")


                        End If

                    Case 2

                        If isSimbolo(caracteres(j)) = True Then

                            estado = 1

                            auxiliar = auxiliar + caracteres(j)

                            Analisis()

                            pintaSimbolos(caracteres(j))

                            contColumnas += 1

                        ElseIf Char.IsLetter(caracteres(j)) Or caracteres(j) = "_" Then

                            estado = 2

                            auxiliar = auxiliar + caracteres(j)

                            auxiliar2 = auxiliar2 + caracteres(j)

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                            contColumnas += 1

                        ElseIf Char.IsDigit(caracteres(j)) Or caracteres(j) = "_" Then

                            estado = 2

                            auxiliar = auxiliar + caracteres(j)

                            auxiliar2 = auxiliar2 + caracteres(j)

                            auxiliarPintar = auxiliarPintar + caracteres(j)


                            contColumnas += 1

                        ElseIf caracteres(j) = " " Then

                            contColumnas += 1

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                        ElseIf caracteres(j) = Chr(34) Or caracteres(j) = ChrW(&H201C) Then

                            estado = 3

                            contador += 1

                            misTokens.agregarToken(contador, caracteres(j), "Simbolo de comilla " & Chr(34), contColumnas, contFilas)

                            setColores(caracteres(j), Color.Purple)

                            contColumnas += 1

                        ElseIf caracteres(j) = Chr(9) Or caracteres(j) = Chr(13) Or caracteres(j) = Chr(8) Then

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                        ElseIf caracteres(j) = Chr(10) Then

                            contFilas += 1

                            contColumnas = 0

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                        Else

                            Reportes = False

                                contColumnas += 1

                            contadorError += 1

                            setColores(caracteres(j), Color.Blue)

                            misErrores.AgregarError(contadorError, caracteres(j), "Error Lexico", contColumnas, contFilas, "Simbolo no reconocido")

                        End If

                    Case 3


                        If caracteres(j) = Chr(34) Or caracteres(j) = ChrW(&H201D) Then

                            contador += 1

                            setColores(auxiliar2, Color.Purple)

                            misTokens.agregarToken(contador, auxiliar2, "Comentario", contColumnas, contFilas)

                            contColumnas += 1

                            auxiliar2 = ""

                            auxiliarPintar = ""

                            contador += 1

                            misTokens.agregarToken(contador, caracteres(j), "Simbolo Comillas " & Chr(34), contColumnas, contFilas)

                            setColores(caracteres(j), Color.Purple)

                            estado = 2

                        ElseIf caracteres(j) = Chr(9) Or caracteres(j) = Chr(13) Or caracteres(j) = Chr(8) Then

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                        ElseIf caracteres(j) = Chr(10) Then

                            contFilas += 1

                            contColumnas = 0

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                        Else

                            auxiliar2 = auxiliar2 + caracteres(j)

                            auxiliarPintar = auxiliarPintar + caracteres(j)

                            contColumnas += 1

                        End If


                    Case Else

                End Select

            Next

            'aqui se incrementa contFilas
            contFilas += 1
            contColumnas = 0
        Next

        MessageBox.Show("¡Analisis Terminado!")

    End Sub

    Sub pintaSimbolos(ByVal Simbolos As String) 'con este metodo vamos a pintar simbolos

        If Simbolos = "[" Then

            auxiliarPintar = ""

            setColores(Simbolos, Color.Red)

            contador += 1

            misTokens.agregarToken(contador, "[", "Corchete abierto ", contColumnas, contFilas)

        ElseIf Simbolos = "]" Then

            setColores(Simbolos, Color.Red)

            contador += 1

            misTokens.agregarToken(contador, "]", "Corchete  cerrado ", contColumnas, contFilas)

        ElseIf Simbolos = "{" Then

            setColores(Simbolos, Color.Red)

            contador += 1

            misTokens.agregarToken(contador, "{", "Llave abierta ", contColumnas, contFilas)

        ElseIf Simbolos = "}" Then

            setColores(Simbolos, Color.Red)

            contador += 1

            misTokens.agregarToken(contador, "}", "Llave cerrada", contColumnas, contFilas)

        ElseIf Simbolos = "(" Then

            setColores(Simbolos, Color.Red)

            contador += 1

            misTokens.agregarToken(contador, "(", "Parentesis abierto", contColumnas, contFilas)

        ElseIf Simbolos = ")" Then

            setColores(Simbolos, Color.Red)

            contador += 1

            misTokens.agregarToken(contador, ")", "Parentesis cerrador", contColumnas, contFilas)

        ElseIf Simbolos = "." Then

            setColores(Simbolos, Color.Black)

            contador += 1

            misTokens.agregarToken(contador, ".", "Punto", contColumnas, contFilas)

        ElseIf Simbolos = ":" Then

            setColores(Simbolos, Color.Black)

            contador += 1

            misTokens.agregarToken(contador, ":", "Dos puntos", contColumnas, contFilas)

        ElseIf Simbolos = ";" Then

            setColores(Simbolos, Color.Black)

            contador += 1

            misTokens.agregarToken(contador, ";", "Punto y coma", contColumnas, contFilas)

        ElseIf Simbolos = "," Then

            setColores(Simbolos, Color.Black)


            contador += 1

            misTokens.agregarToken(contador, ",", "Coma", contColumnas, contFilas)

        ElseIf Simbolos = "+" Then

            setColores(Simbolos, Color.Green)

            contador += 1

            misTokens.agregarToken(contador, "+", "Signo mas", contColumnas, contFilas)

        ElseIf Simbolos = "-" Then

            setColores(Simbolos, Color.Green)

            contador += 1

            misTokens.agregarToken(contador, "-", "Signo menos", contColumnas, contFilas)

        ElseIf Simbolos = "#" Then

            setColores(Simbolos, Color.Green)

            contador += 1

            misTokens.agregarToken(contador, "#", "Numeral", contColumnas, contFilas)

        ElseIf Simbolos = "=" Then

            contador += 1

            misTokens.agregarToken(contador, "=", "Igualacion", contColumnas, contFilas)

        End If

    End Sub

    Sub setColores(ByVal seleccion As String, ByVal color As Color) 'cambia de colores a las letras y signos

        Dim inicioTexto As Integer = 0

        Dim finTexto As Integer

        finTexto = richATexto.Text.LastIndexOf(seleccion)

        While inicioTexto < finTexto

            richATexto.Find(seleccion, inicioTexto, richATexto.TextLength, RichTextBoxFinds.MatchCase)

            richATexto.SelectionBackColor = color

            inicioTexto = richATexto.Text.IndexOf(seleccion, inicioTexto) + 1

        End While

    End Sub

    Function isSimbolo(ByVal simbolo As String)
        Dim esSimbolo As Boolean = False

        For k = 0 To Simbolos.Length - 1

            If String.Compare(Simbolos(k), simbolo, True) = 0 Then

                esSimbolo = True

                Exit For

            End If

        Next

        Return esSimbolo

    End Function

    Sub Analisis() 'Hace el analisis para ver si es palabra reservada o identificador lo agrega a su listado correspondiente

        If auxiliar2.Length = 5 Or auxiliar2.Length = 9 Or auxiliar2.Length = 7 Or auxiliar2.Length = 10 Or auxiliar2.Length = 6 Then '  VERSIÓN 2

            For z = 0 To PalabraReservada.Length - 1

                If String.Compare(auxiliar2, PalabraReservada(z), True) = 0 Then

                    If validarNombre = True Then

                        auxiliar2 = ""
                        auxiliarPintar = ""

                        validarNombre = False

                    ElseIf String.Compare(auxiliar2, "Nombre", True) = 0 Then

                        validarNombre = True

                        ValidarAsociacion = False

                        contador += 1

                        misTokens.agregarToken(contador, auxiliar2, "Palabra Reservada", contColumnas, contFilas)

                        auxiliar2 = ""

                        setColores(auxiliarPintar, Color.Yellow) '------------
                        auxiliarPintar = ""

                    ElseIf String.Compare(auxiliar2, "Asociacion", True) = 0 Then

                        ValidarAsociacion = True

                        contador += 1

                        misTokens.agregarToken(contador, auxiliar2, "Palabra Reservada", contColumnas, contFilas)

                        auxiliar2 = ""

                        setColores(auxiliarPintar, Color.Yellow)
                        auxiliarPintar = ""

                    Else

                        ValidarAsociacion = False


                        contador += 1

                        misTokens.agregarToken(contador, auxiliar2, "Palabra Reservada", contColumnas, contFilas)

                        auxiliar2 = ""

                        setColores(auxiliarPintar, Color.Yellow)
                        auxiliarPintar = ""

                    End If

                End If

            Next



            If Not auxiliar2 = "" Then

                If validarNombre = True Then

                    misClases.AgregarClase(auxiliar2) 'agrega los nombres de las clases a un listado

                    validarNombre = False

                End If

                If ValidarAsociacion = True Then

                    creaAsociacion(auxiliar2)

                End If

                contador += 1

                misTokens.agregarToken(contador, auxiliar2, "Identificador", contColumnas, contFilas)

                auxiliar2 = ""

                auxiliarPintar = ""

            End If

        ElseIf auxiliar2 = "" Then

        Else


            If validarNombre = True Then

                misClases.AgregarClase(auxiliar2)

                validarNombre = False

            End If

            If ValidarAsociacion = True Then

                creaAsociacion(auxiliar2)

            End If

            contador += 1

            misTokens.agregarToken(contador, auxiliar2, "Identificador", contColumnas, contFilas)

            auxiliar2 = ""
            auxiliarPintar = ""

        End If


    End Sub

    Sub ReporteTokens() 'Crea un archivo html del reporte de tokens y lo abre automaticamente

        Dim archivo As New IO.StreamWriter("ReporteTokens.html")

        archivo.Write("<HTML><body><table style=" & Chr(34) & "width:100%" & Chr(34) & ">" & "<tr> <th>No</th> <th>Lexema</th> <th>Tipo</th> <th>Columna</th> <th>Fila</th> </tr>" &
              Environment.NewLine & misTokens.mostrarToken & "</table></body></HTML>")

        archivo.Flush()

        archivo.Close()

        Process.Start("ReporteTokens.html")

    End Sub

    Sub ReporteErrores() 'crea un archivo html del reporte de errores y lo abre automaticamente

        Dim archivo As New IO.StreamWriter("ReporteErrores.html")

        archivo.Write("<HTML><body><table style=" & Chr(34) & "width:100%" & Chr(34) & ">" & "<tr> <th>No</th> <th>Error</th> <th>Tipo</th> <th>Columna</th> <th>Fila</th> <th>Descripcion</th> </tr>" &
              Environment.NewLine & misErrores.mostrarErrores & "</table></body></HTML>")

        archivo.Flush()

        archivo.Close()

        Process.Start("ReporteErrores.html")

    End Sub

    Sub Graficar()

        Dim archivo As New IO.StreamWriter("Grafica.txt")

        archivo.Write("digraph G {" & creaAsoc() & "}")

        archivo.Flush()

        archivo.Close()

        Dim Path As String = "bin2\dot.exe -Tjpg Grafica.txt -o Figure1.jpg"

        Dim prog As VariantType

        prog = Shell(Path, 1)

        Process.Start("Figure1.jpg")

    End Sub

    Sub creaAsociacion(ByVal texto As String)

        If contadorClases = 0 Then

            palabraAsociacion = palabraAsociacion & ";" & texto

            contadorClases += 1

        ElseIf contadorClases = 2 Then

            palabraAsociacion = palabraAsociacion & ";" & texto

            contadorClases = 0

        End If

        For z = 0 To tipAsociacion.Length - 1

            If String.Compare(texto, tipAsociacion(z), True) = 0 And contadorClases = 1 Then

                If String.Compare(texto, "Agregacion", True) = 0 Then

                    palabraAsociacion = palabraAsociacion & ";" & "odiamond"

                    contadorClases += 1

                ElseIf String.Compare(texto, "Composicion", True) = 0 Then

                    palabraAsociacion = palabraAsociacion & ";" & "diamond"

                    contadorClases += 1

                ElseIf String.Compare(texto, "Herencia", True) = 0 Then

                    palabraAsociacion = palabraAsociacion & ";" & "onormal"

                    contadorClases += 1

                ElseIf String.Compare(texto, "AsociacionSimple", True) = 0 Then

                    palabraAsociacion = palabraAsociacion & ";" & "none"

                    contadorClases += 1

                End If

                Exit For

            End If

        Next

    End Sub


    Function creaAsoc()

        Dim buscarPalabra() As String = Split(palabraAsociacion, ";")

        Dim concatena As String = ""

        Dim palabra1 As String = ""

        Dim asoc As String = ""

        Dim Palabra2 As String = ""

        For k = 1 To buscarPalabra.Length - 1 Step 3

            Dim let1 As Integer = k + 1

            Dim let2 As Integer = k + 2

            If let2 > buscarPalabra.Length - 1 Then

                Exit For

            End If

            If misClases.ExisteClase(buscarPalabra(k)) = True And misClases.ExisteClase(buscarPalabra(let2)) = True Then

                concatena = concatena & Chr(34) & buscarPalabra(k) & Chr(34) & "->" & Chr(34) & buscarPalabra(let2) & Chr(34) &
                    " [arrowhead=" & Chr(34) & buscarPalabra(let1) & Chr(34) & "]" & Environment.NewLine

            ElseIf misClases.ExisteClase(buscarPalabra(k)) = True Then

                concatena = concatena & Chr(34) & buscarPalabra(k) & Chr(34) &
                    " [arrowhead=" & Chr(34) & buscarPalabra(let1) & Chr(34) & "]" & Environment.NewLine

            ElseIf misClases.ExisteClase(buscarPalabra(let2)) = True Then

                concatena = concatena & Chr(34) & buscarPalabra(let2) & Chr(34) &
                    " [arrowhead=" & Chr(34) & buscarPalabra(let1) & Chr(34) & "]" & Environment.NewLine

            End If

        Next

        Return concatena

    End Function


    Private existe As Boolean = False

    Private ruta As String

    Private contenidoArchivo As String

    Private caracteres As String

    Private estado As Integer = 0

    Private Simbolos() As String = {"[", "]", "{", "}", "+", "-", "#", "=", ";", ":", "(", ")", ","}

    Private PalabraReservada() As String = {"Clase", "Atributos", "Metodos", "Asociacion", "Nombre", "Comentario"}

    Private tipAsociacion() As String = {"Agregacion", "Composicion", "Herencia", "AsociacionSimple"}

    Private codGraphics As String = ""

    Private Preanalisis() As String

    Private sigToken As Integer = 0

    Private contFilas As Integer = 0

    Private contColumnas As Integer = 0

    Private auxiliar As String = ""

    Private auxiliar2 As String = ""

    Private auxiliarPintar As String = ""

    Dim ValidarAsociacion As Boolean = False

    Dim contador As Integer = 0

    Dim contadorClases As Integer = 0

    Dim contadorError As Integer = 0

    Dim misTokens As New ListaToken()

    Dim misClases As New ListaClases()

    Dim misErrores As New ListadoErrores()

    Dim validarNombre As Boolean = False

    Dim palabraAsociacion As String = ""

    Dim Reportes As Boolean = True

    Private Sub MReporte_Click(sender As Object, e As EventArgs) Handles MReporte.Click

        If Reportes = True Then

            ReporteTokens()

        Else

            ReporteErrores()

        End If


    End Sub

    Private Sub MDiagramar_Click(sender As Object, e As EventArgs) Handles MDiagramar.Click

        If Reportes = True Then

            Graficar()

        Else

            MessageBox.Show("Existieron errores en el analisis no es posible graficar.")


        End If




    End Sub

    Private Sub AcercaDeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AcercaDeToolStripMenuItem.Click

        MessageBox.Show("Analizador lexico V1 " & Environment.NewLine &
                        "Hecho por: Dr4k0n 360 " & Environment.NewLine &
                        "Carnet: --------")

    End Sub

    Private Sub ManualToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManualToolStripMenuItem.Click

        Process.Start("ManualUsuario.pdf")

        Process.Start("ManualTecnico.pdf")


    End Sub

    Private Sub MostrarEjemploToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MostrarEjemploToolStripMenuItem.Click
        richATexto.Text = "[Clase]{

[NomBre]=ejemplo1;

[Atribu               Tos]{

(+) ident1:Tipo1;
(-) ident2:Tipo2;
(#) ident3:Tipo3;


}

[Meto                            dos]{

(+) i                                     denM1:tipoR1;
(-) idenM2:tipoR2;
(#) idenM3:tipoR3;

}
}
[Clase]{

[Nom                                   Bre]=ejemplo2;

[AtribuTos]{

(+) ident4:Tipo4;
(-) ident5:                                           Tipo5;
(#) ident6:Tipo6;


}

[Metodos]{

(+) idenM4:tipoR4;
(-) iden                                        M5:tipoR5;
(#) idenM6:tipoR6;

}

}

[ComEn			taRio]  {

[NomBre]=ejemplo3;
[TextO]=" + Chr(34) + "ESto es@@@@@@@ un Comentario" + Chr(34) + ";

}


[Asociacion]{

ejemplo1:herencia:ejemplo2;
ejemplo3:Composicion:ejemplo1;
ejemplo5:agregacion:ejemplo6;
ejemplo7:Asociacionsimple:ejemplo8;


}"
    End Sub
End Class
