﻿Public Class NodoToken

    Sub New(ByVal num As Integer, ByVal lex As String, ByVal tip As String, ByVal col As Integer,
            ByVal lin As Integer)

        Me.numeral = num

        Me.lexema = lex

        Me.tipo = tip

        Me.columna = col

        Me.linea = lin

    End Sub

    Sub New(ByVal num As Integer, ByVal lex As String, ByVal tip As String, ByVal col As Integer,
            ByVal lin As Integer, ByVal noSig As NodoToken)

        Me.numeral = num

        Me.lexema = lex

        Me.tipo = tip

        Me.columna = col

        Me.linea = lin

        Me.siguiente = noSig


    End Sub

    Public numeral As Integer

    Public lexema As String

    Public tipo As String

    Public columna As Integer

    Public linea As Integer

    Public siguiente As NodoToken

End Class
