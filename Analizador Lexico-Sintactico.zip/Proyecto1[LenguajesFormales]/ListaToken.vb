﻿Public Class ListaToken


    Sub New()
        inicio = Nothing

        fin = Nothing
    End Sub

    'Agregar al inicio
    Sub agregarToken(ByVal num As Integer, ByVal lex As String, ByVal tip As String,
                ByVal col As Integer,
            ByVal lin As Integer) 'ingreso de datos a los nodos

        inicio = New NodoToken(num, lex, tip, col, lin, inicio)

        If IsDBNull(fin) Then

            fin = inicio

        End If

        contador += 1

    End Sub

    'Sub mostrar()
    '    Dim recorrer As NodoToken = inicio

    '    While Not IsDBNull(recorrer)

    '    End While

    'End Sub

    Function mostrarToken() As String 'devuelve los valores de tokens en forma de tabla

        Dim recorrer As NodoToken = inicio

        Dim valoresToken As String = ""

        ' While Not IsDBNull(recorrer)
        For k = 0 To contador - 1

            valoresToken = valoresToken & "<tr>" & "<td>" & Convert.ToString(recorrer.numeral) & "</td>" & "         " & "<td>" & recorrer.lexema & "</td>" & "         " &
             "<td>" & recorrer.tipo & "</td>" & "         " & "<td>" & Convert.ToString(recorrer.columna) & "</td>" & "         " & "<td>" & Convert.ToString(recorrer.linea) & "</td>" & "</tr>" & vbNewLine

            'MessageBox.Show(Convert.ToString(recorrer.numeral) + "         " + recorrer.lexema + "         " +
            'recorrer.tipo + "         " + Convert.ToString(recorrer.columna) + "         " + Convert.ToString(recorrer.linea) + vbNewLine)

            'MessageBox.Show(valoresToken)              **** todo aqui comentado no funciona****

            recorrer = recorrer.siguiente 'aqui hay error

            'End While
        Next


        'MessageBox.Show(valoresToken)

        Return valoresToken

    End Function

    Function ListaToken() As String

        Dim recorrer As NodoToken = inicio

        Dim listatokens As String = ""

        For k = 0 To contador - 1

            listatokens = listatokens + recorrer.lexema + vbNewLine

            recorrer = recorrer.siguiente
        Next

        Return listatokens

    End Function

    Function CantidadTokens() As Integer

        Return contador

    End Function

    Public inicio, fin As NodoToken

    Private contador As Integer = 0


    Dim valoresToken As String = ""
End Class
