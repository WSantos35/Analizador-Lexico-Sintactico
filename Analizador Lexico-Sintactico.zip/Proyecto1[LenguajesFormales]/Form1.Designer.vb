﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PPrincipal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ArchivoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MAbrir = New System.Windows.Forms.ToolStripMenuItem()
        Me.MGuardar = New System.Windows.Forms.ToolStripMenuItem()
        Me.MGuardarComo = New System.Windows.Forms.ToolStripMenuItem()
        Me.MSalir = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnalizarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MAnLexico = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MReporte = New System.Windows.Forms.ToolStripMenuItem()
        Me.MDiagramar = New System.Windows.Forms.ToolStripMenuItem()
        Me.AyudaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManualToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AcercaDeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.richATexto = New System.Windows.Forms.RichTextBox()
        Me.MostrarEjemploToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ArchivoToolStripMenuItem, Me.AnalizarToolStripMenuItem, Me.ReportesToolStripMenuItem, Me.MostrarEjemploToolStripMenuItem, Me.AyudaToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(729, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ArchivoToolStripMenuItem
        '
        Me.ArchivoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MAbrir, Me.MGuardar, Me.MGuardarComo, Me.MSalir})
        Me.ArchivoToolStripMenuItem.Name = "ArchivoToolStripMenuItem"
        Me.ArchivoToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.ArchivoToolStripMenuItem.Text = "Archivo"
        '
        'MAbrir
        '
        Me.MAbrir.Name = "MAbrir"
        Me.MAbrir.Size = New System.Drawing.Size(161, 22)
        Me.MAbrir.Text = "Abrir"
        '
        'MGuardar
        '
        Me.MGuardar.Name = "MGuardar"
        Me.MGuardar.Size = New System.Drawing.Size(161, 22)
        Me.MGuardar.Text = "Guardar"
        '
        'MGuardarComo
        '
        Me.MGuardarComo.Name = "MGuardarComo"
        Me.MGuardarComo.Size = New System.Drawing.Size(161, 22)
        Me.MGuardarComo.Text = "Guardar Como..."
        '
        'MSalir
        '
        Me.MSalir.Name = "MSalir"
        Me.MSalir.Size = New System.Drawing.Size(161, 22)
        Me.MSalir.Text = "Salir"
        '
        'AnalizarToolStripMenuItem
        '
        Me.AnalizarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MAnLexico})
        Me.AnalizarToolStripMenuItem.Name = "AnalizarToolStripMenuItem"
        Me.AnalizarToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.AnalizarToolStripMenuItem.Text = "Analizar"
        '
        'MAnLexico
        '
        Me.MAnLexico.Name = "MAnLexico"
        Me.MAnLexico.Size = New System.Drawing.Size(180, 22)
        Me.MAnLexico.Text = "Analisis Lexico"
        '
        'ReportesToolStripMenuItem
        '
        Me.ReportesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MReporte, Me.MDiagramar})
        Me.ReportesToolStripMenuItem.Name = "ReportesToolStripMenuItem"
        Me.ReportesToolStripMenuItem.Size = New System.Drawing.Size(65, 20)
        Me.ReportesToolStripMenuItem.Text = "Reportes"
        '
        'MReporte
        '
        Me.MReporte.Name = "MReporte"
        Me.MReporte.Size = New System.Drawing.Size(129, 22)
        Me.MReporte.Text = "Reporte"
        '
        'MDiagramar
        '
        Me.MDiagramar.Name = "MDiagramar"
        Me.MDiagramar.Size = New System.Drawing.Size(129, 22)
        Me.MDiagramar.Text = "Diagramar"
        '
        'AyudaToolStripMenuItem
        '
        Me.AyudaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ManualToolStripMenuItem, Me.AcercaDeToolStripMenuItem})
        Me.AyudaToolStripMenuItem.Name = "AyudaToolStripMenuItem"
        Me.AyudaToolStripMenuItem.Size = New System.Drawing.Size(53, 20)
        Me.AyudaToolStripMenuItem.Text = "Ayuda"
        '
        'ManualToolStripMenuItem
        '
        Me.ManualToolStripMenuItem.Name = "ManualToolStripMenuItem"
        Me.ManualToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.ManualToolStripMenuItem.Text = "Manual"
        '
        'AcercaDeToolStripMenuItem
        '
        Me.AcercaDeToolStripMenuItem.Name = "AcercaDeToolStripMenuItem"
        Me.AcercaDeToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.AcercaDeToolStripMenuItem.Text = "Acerca de..."
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'richATexto
        '
        Me.richATexto.Location = New System.Drawing.Point(26, 27)
        Me.richATexto.Name = "richATexto"
        Me.richATexto.Size = New System.Drawing.Size(678, 395)
        Me.richATexto.TabIndex = 4
        Me.richATexto.Text = ""
        '
        'MostrarEjemploToolStripMenuItem
        '
        Me.MostrarEjemploToolStripMenuItem.Name = "MostrarEjemploToolStripMenuItem"
        Me.MostrarEjemploToolStripMenuItem.Size = New System.Drawing.Size(103, 20)
        Me.MostrarEjemploToolStripMenuItem.Text = "MostrarEjemplo"
        '
        'PPrincipal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(729, 450)
        Me.Controls.Add(Me.richATexto)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MaximizeBox = False
        Me.Name = "PPrincipal"
        Me.Text = "Analizador Lexico v1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ArchivoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AnalizarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReportesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MAbrir As ToolStripMenuItem
    Friend WithEvents MGuardar As ToolStripMenuItem
    Friend WithEvents MGuardarComo As ToolStripMenuItem
    Friend WithEvents MSalir As ToolStripMenuItem
    Friend WithEvents MAnLexico As ToolStripMenuItem
    Friend WithEvents MReporte As ToolStripMenuItem
    Friend WithEvents MDiagramar As ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents AyudaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManualToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AcercaDeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents richATexto As RichTextBox
    Friend WithEvents MostrarEjemploToolStripMenuItem As ToolStripMenuItem
End Class
