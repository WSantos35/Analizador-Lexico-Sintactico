﻿Public Class NodoErrores


    Sub New(ByVal ser As Integer, ByVal lexE As String, ByVal tipo As String, ByVal colE As Integer, ByVal filE As Integer, ByVal desc As String)

        Me.serial = ser

        Me.lexError = lexE

        Me.columError = colE

        Me.FilError = filE

        Me.tipoError = tipo

        Me.descripcion = desc

    End Sub

    Sub New(ByVal ser As Integer, ByVal lexE As String, ByVal tipo As String, ByVal colE As Integer, ByVal filE As Integer, ByVal desc As String, ByVal sigNo As NodoErrores)

        Me.serial = ser

        Me.lexError = lexE

        Me.columError = colE

        Me.FilError = filE

        Me.siguiente = sigNo

        Me.tipoError = tipo

        Me.descripcion = desc

    End Sub



    Public siguiente As NodoErrores

    Public serial As Integer

	Public lexError As String

	Public columError As Integer

    Public FilError As Integer

    Public tipoError As String

    Public descripcion As String

End Class
